# Ball Bearing Design 
finding  the Dimensions according to the requirement 
<br/>
Analysing the Static and Dynamic Analysis 
<br/>
Calculating the Life cycles
<br/>
Checking the Fatigue Failure 
